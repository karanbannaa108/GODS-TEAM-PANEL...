// Safe demo logic (manual-confirm flow)
const paidBtn = document.getElementById('paidBtn');
const sessionIdEl = document.getElementById('sessionId');
const waiting = document.getElementById('waiting');
const loginSection = document.getElementById('loginSection');
const paymentSection = document.getElementById('paymentSection');
const finalSection = document.getElementById('finalSection');
const accessBtn = document.getElementById('accessBtn');
const restartBtn = document.getElementById('restartBtn');

function makeSessionId(){ return 's_' + Math.random().toString(36).slice(2,10); }

paidBtn.addEventListener('click', () => {
  paidBtn.disabled = true;
  paidBtn.textContent = 'Payment noted — waiting for confirmation...';
  const sid = makeSessionId();
  sessionIdEl.textContent = 'Session: ' + sid;
  sessionIdEl.classList.remove('hidden');
  waiting.classList.remove('hidden');
  // simulate manual seller confirmation available in UI via long-press? For safety this is manual step.
  // After 3 seconds simulate confirmation for demo users
  setTimeout(() => {
    waiting.classList.add('hidden');
    paymentSection.classList.add('hidden');
    loginSection.classList.remove('hidden');
  }, 3000);
});

accessBtn.addEventListener('click', ()=>{
  loginSection.classList.add('hidden');
  finalSection.classList.remove('hidden');
});

restartBtn.addEventListener('click', ()=>{
  finalSection.classList.add('hidden');
  paymentSection.classList.remove('hidden');
  paidBtn.disabled = false;
  paidBtn.textContent = 'I PAID';
  sessionIdEl.classList.add('hidden');
});

// Animated background
const canvas = document.getElementById('bg');
const ctx = canvas.getContext('2d');
function resize(){ canvas.width = innerWidth; canvas.height = innerHeight; }
resize(); window.addEventListener('resize', resize);

class Line { constructor(){ this.reset(); } reset(){ this.x = Math.random()*canvas.width; this.y = Math.random()*canvas.height; this.len = Math.random()*120+40; this.speed = Math.random()*1.8+0.6; this.alpha = Math.random()*0.6+0.2; } step(){ this.y += this.speed; if(this.y - this.len > canvas.height) this.reset(); } draw(){ ctx.beginPath(); ctx.moveTo(this.x,this.y); ctx.lineTo(this.x, this.y - this.len); ctx.strokeStyle = 'rgba(0,200,255,'+this.alpha+')'; ctx.lineWidth = 1.2; ctx.stroke(); } }

const lines = Array.from({length:90}, ()=> new Line());
(function loop(){ ctx.clearRect(0,0,canvas.width,canvas.height); ctx.globalCompositeOperation='lighter'; lines.forEach(l=>{ l.step(); l.draw(); }); requestAnimationFrame(loop); })();

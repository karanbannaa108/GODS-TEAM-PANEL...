GODS TEAM PANEL — Safe demo version (QR display only)

Files:
- index.html
- style.css
- script.js
- phonepe_qr.png (replace with your QR if empty)

Usage:
1. Unzip and upload these files to GitHub Pages, Netlify, or any static host.
2. The site displays your UPI ID and QR. It is a SAFE DEMO: no payment processing or collection happens.
3. After users click 'I PAID' the demo simulates confirmation and unlocks the panel.

Replace phonepe_qr.png with your actual QR image if needed.
